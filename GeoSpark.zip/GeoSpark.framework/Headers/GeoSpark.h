//
//  GeoSpark.h
//  GeoSpark
//
//  Created by GeoSpark Mac #1 on 22/10/18.
//  Copyright © 2018 GeoSpark, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GeoSpark.
FOUNDATION_EXPORT double GeoSparkVersionNumber;

//! Project version string for GeoSpark.
FOUNDATION_EXPORT const unsigned char GeoSparkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GeoSpark/PublicHeader.h>


